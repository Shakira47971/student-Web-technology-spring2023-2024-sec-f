<?php 
    
    header('location: ../View/login.php');
?>